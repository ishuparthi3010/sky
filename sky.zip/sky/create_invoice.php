<!doctype html>
<html lang="en">


<!-- Mirrored from demo.dashboardpack.com/architectui-html-pro/dashboards-crm.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 11 Mar 2021 13:24:01 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>CRM Dashboard - Examples of just how powerful ArchitectUI really is!</title>
    <meta name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="description" content="Examples of just how powerful ArchitectUI really is!">

    <!-- Disable tap highlight on IE -->
    <meta name="msapplication-tap-highlight" content="no">

<link href="main.d810cf0ae7f39f28f336.css" rel="stylesheet"></head>

<body>
    <?php include 'header.php';?>
            <div class="app-main__outer">
                <div class="app-main__inner">
                    <div class="app-page-title">
                        <div class="page-title-wrapper">
                            <div class="page-title-heading">
                                <div class="page-title-icon">
                                    <i class="lnr-picture text-danger"></i>
                                </div>
                                <div>Invoice
                                    <div class="page-title-subheading">Inline validation is very easy to implement using the Architect Framework.</div>
                                </div>
                            </div>
                            <div class="page-title-actions">
                               
                                <div class="d-inline-block dropdown">
                                   
                                    <button type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="btn-shadow  btn btn-info">
                                        <span class="btn-icon-wrapper pr-2 opacity-7">
                                           <-
                                        </span>
                                        Back
                                    </button>
                                    </a>
                                </div>
                            </div>    </div>
                    </div>        
                    <div class="main-card mb-3 card">
                        <div class="card-body">
                            <h5 class="card-title">Create Invoice</h5>
                            <form id="signupForm" class="col-md-10 mx-auto" method="post" action="#">
                                <div class="form-group">
                                    <label for="firstname">First name</label>
                                    <div>
                                        <input type="text" class="form-control" id="firstname" name="firstname" placeholder="First name" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="lastname">Last name</label>
                                    <div>
                                        <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Last name" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="username">Username</label>
                                    <div>
                                        <input type="text" class="form-control" id="username" name="username" placeholder="Username" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <div>
                                        <input type="text" class="form-control" id="email" name="email" placeholder="Email" />
                                    </div>
                                </div>
            
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Password" />
                                </div>
                                <div class="form-group">
                                    <label for="confirm_password">Confirm password</label>
                                    <div>
                                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm password" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div>
                                        <div class="form-check">
                                            <input type="checkbox" id="agree" name="agree" value="agree" class="form-check-input" />
                                            <label class="form-check-label">Please agree to our policy</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary" name="signup" value="Sign up">SUBMIT</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php include 'footer.php';?>
    <div class="app-drawer-overlay d-none animated fadeIn"></div><script type="text/javascript" src="assets/scripts/main.d810cf0ae7f39f28f336.js"></script></body>


<!-- Mirrored from demo.dashboardpack.com/architectui-html-pro/forms-validation.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 11 Mar 2021 13:24:26 GMT -->
</html>